#include "Framework.h"

PlayerData* PlayerData::instance = nullptr;

PlayerData::PlayerData()
{

}

PlayerData::~PlayerData()
{

}
